package Capa_Datos;
import java.util.ArrayList;

public class ListaParticipantes {
    public static ArrayList listaParticipantes = new ArrayList();
    
    public static void añadirParticipante(Object objparticipant){
        listaParticipantes.add(objparticipant);
    }
    
    public static ArrayList Consultar(){
        return listaParticipantes;
    }
    
}
