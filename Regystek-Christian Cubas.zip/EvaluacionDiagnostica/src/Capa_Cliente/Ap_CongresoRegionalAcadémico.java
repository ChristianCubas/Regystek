package Capa_Cliente;
import Capa_Cliente.FrmInterfaz;

public class Ap_CongresoRegionalAcadémico {

    public static void main(String[] args) {
        FrmInterfaz interfaz = new FrmInterfaz();
        interfaz.setVisible(true);
        interfaz.setLocationRelativeTo(null);
    }
    
}
