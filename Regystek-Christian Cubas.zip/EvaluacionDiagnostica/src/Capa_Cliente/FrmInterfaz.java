/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Capa_Cliente;
import Capa_Cliente.*;
import javax.swing.JFrame;

public class FrmInterfaz extends javax.swing.JFrame {

    public FrmInterfaz() {
        initComponents();
        setTitle("Evaluacion Diagnostica - Christian Cubas Jaramillo");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Contorno = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        MnuRegistrar = new javax.swing.JMenu();
        MnuMostrar = new javax.swing.JMenu();
        MnuReportes = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Contorno.setBackground(new java.awt.Color(0, 153, 102));

        javax.swing.GroupLayout ContornoLayout = new javax.swing.GroupLayout(Contorno);
        Contorno.setLayout(ContornoLayout);
        ContornoLayout.setHorizontalGroup(
            ContornoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 496, Short.MAX_VALUE)
        );
        ContornoLayout.setVerticalGroup(
            ContornoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 333, Short.MAX_VALUE)
        );

        MnuRegistrar.setText("Registrar");
        MnuRegistrar.addMenuListener(new javax.swing.event.MenuListener() {
            public void menuCanceled(javax.swing.event.MenuEvent evt) {
            }
            public void menuDeselected(javax.swing.event.MenuEvent evt) {
            }
            public void menuSelected(javax.swing.event.MenuEvent evt) {
                MnuRegistrarMenuSelected(evt);
            }
        });
        MnuRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnuRegistrarActionPerformed(evt);
            }
        });
        jMenuBar1.add(MnuRegistrar);

        MnuMostrar.setText("Mostrar Datos");
        MnuMostrar.addMenuListener(new javax.swing.event.MenuListener() {
            public void menuCanceled(javax.swing.event.MenuEvent evt) {
            }
            public void menuDeselected(javax.swing.event.MenuEvent evt) {
            }
            public void menuSelected(javax.swing.event.MenuEvent evt) {
                MnuMostrarMenuSelected(evt);
            }
        });
        jMenuBar1.add(MnuMostrar);

        MnuReportes.setText("Reportes");
        MnuReportes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnuReportesActionPerformed(evt);
            }
        });

        jMenuItem1.setText("Reporte 1");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        MnuReportes.add(jMenuItem1);

        jMenuItem2.setText("Reporte 2");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        MnuReportes.add(jMenuItem2);

        jMenuItem3.setText("Reporte 3");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        MnuReportes.add(jMenuItem3);

        jMenuBar1.add(MnuReportes);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Contorno, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Contorno, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MnuRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnuRegistrarActionPerformed

    }//GEN-LAST:event_MnuRegistrarActionPerformed

    private void MnuRegistrarMenuSelected(javax.swing.event.MenuEvent evt) {//GEN-FIRST:event_MnuRegistrarMenuSelected
        FrmRegistrar registrar = new FrmRegistrar();
        Contorno.add(registrar);
        registrar.setVisible(true);
    }//GEN-LAST:event_MnuRegistrarMenuSelected

    private void MnuMostrarMenuSelected(javax.swing.event.MenuEvent evt) {//GEN-FIRST:event_MnuMostrarMenuSelected
        FrmMostrar mostrar = new FrmMostrar();
        Contorno.add(mostrar);
        mostrar.setVisible(true);
        mostrar.setLocation(450,0);
    }//GEN-LAST:event_MnuMostrarMenuSelected

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        FrmReporte1 reporte1 = new FrmReporte1();
        Contorno.add(reporte1);
        reporte1.setVisible(true);
        reporte1.setLocation(1100, 0);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        FrmReporte2 reporte2 = new FrmReporte2();
        Contorno.add(reporte2);
        reporte2.setVisible(true);
        reporte2.setLocation(0, 400);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void MnuReportesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnuReportesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MnuReportesActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        FrmReporte3 reporte3 = new FrmReporte3();
        Contorno.add(reporte3);
        reporte3.setVisible(true);
        reporte3.setLocation(1100, 400);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JPanel Contorno;
    private javax.swing.JMenu MnuMostrar;
    private javax.swing.JMenu MnuRegistrar;
    private javax.swing.JMenu MnuReportes;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    // End of variables declaration//GEN-END:variables
}
