package Capa_Negocio;

import Capa_Datos.ListaParticipantes;

public class Participante {
    private String nombre;
    private String sexo;
    private String nivel_estudio;
    private String universidad;
    private float costo;

    public Participante(String nombre, String sexo, String nivel_estudio, String universidad, float costo) {
        this.nombre = nombre;
        this.sexo = sexo;
        this.nivel_estudio = nivel_estudio;
        this.universidad = universidad;
        this.costo = costo;
    }

    public Participante() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getNivel_estudio() {
        return nivel_estudio;
    }

    public void setNivel_estudio(String nivel_estudio) {
        this.nivel_estudio = nivel_estudio;
    }

    public String getUniversidad() {
        return universidad;
    }

    public void setUniversidad(String universidad) {
        this.universidad = universidad;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }
    
    //Pasa datos a la capa de datos
    public void insertar(Participante participant){
        ListaParticipantes.añadirParticipante(participant);
    }
    
}
